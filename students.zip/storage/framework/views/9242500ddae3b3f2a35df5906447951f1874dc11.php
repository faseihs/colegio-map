<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <i class="fa fa-check-circle"></i> <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('primary')): ?>
    <div class="alert alert-primary alert-dismissible" role="alert">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <i class="fa fa-check-square-o"></i> <?php echo e(session('primary')); ?>


    </div>
<?php endif; ?>

<?php if(session('deleted')): ?>
    <div class="alert alert-danger alert-dismissible" role="alert">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <i class="fa fa-close"></i> <?php echo e(session('deleted')); ?>

    </div>
<?php endif; ?><?php /**PATH C:\xampp7\htdocs\fiverr\students\resources\views/includes/flash.blade.php ENDPATH**/ ?>