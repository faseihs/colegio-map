<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12 col-lg-12 col-xl-12 col-sm-12">
                <div class="card">
                    <div class="card-header">Students
                        <div class="float-right">
                            <select onchange="window.location='/student?type='+this.value" class="form-control-sm">
                                <option <?php echo e($type=="current"?'selected':''); ?>  value="current">Current</option>
                                <option <?php echo e($type=="deleted"?'selected':''); ?> value="deleted">Deleted</option>
                            </select>
                            <a class="btn btn-success btn-sm" href="/student/create">Add Student</a></div>
                        </div>


                    <div class="card-body">
                      <?php echo $__env->make('includes.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                       <div class="row">
                           <div class="col-12 table-responsive">
                                   <table style="width:100%" class="table table-sm" id="user-datatable">
                                       <thead>
                                       <tr>
                                         
                                            <th><?php echo e(__('Student ID')); ?></th>
                                           <th><?php echo e(__('Name')); ?></th>
                                           <th><?php echo e(__('Last Name')); ?></th>
                                         
                                           <th><?php echo e(__('Program')); ?></th>
                                         
                                           <th><?php echo e(__("Phone Number")); ?></th>
                                           <th><?php echo e(__("Tutor")); ?></th>
                                           <th><?php echo e(__("Emergency Contact")); ?></th>
                                           <th><?php echo e(__("Created At")); ?></th>
                                           <th>Actions</th>
                                       </tr>
                                       </thead>
                                       <tbody>
                                       <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <tr>
                                              
                                           </tr>

                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </tbody>


                                   </table>
                           </div>
                       </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="/css/datatables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script src="/js/datatables.min.js"></script>
    <?php if(sizeof($students)>0): ?>
        <?php echo $__env->make('includes.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var $datatable = $('#user-datatable');
        var table = $datatable.DataTable({
            "columns": [
                {"data": "id"},
                {"data": "name"},
                {"data": "last_name"},
             /*   {"data": "group"},
                {"data": "dob"},
                {"data": "age"},*/
                {"data": "program"},
             /*   {"data": "classroom_number"},
                {"data": "semester"},
                {"data": "date_of_admission"},*/
                {"data":"contact",render:function (contact) {
                        return contact?contact.phone_number:'-'
                    }},
                {"data":"contact",render:function (contact) {
                        return contact?contact.tutor:'-'
                    }},
                {"data":"contact",render:function (contact) {
                        return contact?contact.emergency_contact:'-'
                    }},
                {"data": "created_at"},
                {"data":"id",render:function (id,row,data) {

                    let s =``;
                         if(data.deleted_at)
                            s+=`<a class="btn btn-success btn-sm" href="/student/${id}/restore">Restore</a>`;

                        if(!data.deleted_at)
                            s+=`<a class="btn btn-sm btn-primary" href="/student/${id}/edit">View/Edit</a>`;

                            s+=`<a class="btn btn-sm btn-danger ml-2" onclick="deleteObj(${id})" href="#">Delete</a>
                            <form method="POST" id="del${id}" action="/student/${id}">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="_method" value="DELETE">
                            </form>`;
                            return s;
                    }},
            ],
            'processing': true,
            'stateSave': false,
            'serverSide': true,
            'ajax': {
                'url': '<?php echo e($type=="deleted"?"student-data-trashed":"student-data"); ?>',
                'type': 'POST'
            },
            'order': [[ 0, 'desc' ]],
            'columnDefs': [
                { "orderable": false, "targets": [-1] },
                { "searchable": false, "targets": [-1] }
            ]
        });
        $( table.table().container() ).removeClass( 'form-inline' );

        $('#user-datatable_processing').html(`<div class="text-center m-4">
  <div class="spinner-border" role="status">
    <span class="sr-only">Loading...</span>
  </div>
</div>`)
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\fiverr\students\resources\views/student/index.blade.php ENDPATH**/ ?>